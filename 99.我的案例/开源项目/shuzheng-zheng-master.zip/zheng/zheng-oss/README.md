# zheng-oss

对象存储系统

- **阿里云** OSS

![阿里云OSS](../project-bootstrap/aliyun-oss-post-callback.png)