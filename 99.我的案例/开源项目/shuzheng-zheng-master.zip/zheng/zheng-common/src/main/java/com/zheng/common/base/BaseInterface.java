package com.zheng.common.base;

/**
 * 系统接口
 * Created by ZhangShuzheng on 2017/6/13.
 */
public interface BaseInterface {

	/**
	 * 系统初始化
	 */
	void init();

}
