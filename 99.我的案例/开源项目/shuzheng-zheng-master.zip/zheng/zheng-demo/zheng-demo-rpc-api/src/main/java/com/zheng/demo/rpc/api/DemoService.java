package com.zheng.demo.rpc.api;

/**
 * 测试接口
 * Created by shuzheng on 2017/4/1.
 */
public interface DemoService {

    String sayHello(String name);

}
