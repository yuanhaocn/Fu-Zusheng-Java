package io.renren.common.validator.group;

/**
 * 更新数据 Group
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2017-03-15 21:21
 */

public interface UpdateGroup {

}
