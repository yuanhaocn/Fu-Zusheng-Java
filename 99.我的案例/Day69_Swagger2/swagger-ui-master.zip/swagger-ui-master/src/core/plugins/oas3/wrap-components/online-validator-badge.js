import { OAS3ComponentWrapFactory } from "../helpers"

// We're disabling the Online Validator Badge until the online validator
// can handle OAS3 specs.
export default OAS3ComponentWrapFactory(() => null)
