# zheng-pay

一站式支付解决方案，统一下单接口，支持支付宝、微信、网银等多种支付方式。不涉及业务的纯粹的支付平台。

![统一扫码支付](../project-bootstrap/zheng-pay.png)