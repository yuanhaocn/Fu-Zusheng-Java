import com.zs.pig.common.constant.Constant;
import com.zs.pig.common.jackson.JsonUtils;
import com.zs.pig.common.redis.test.RedisUtils;
import com.zs.pig.goods.api.model.Product;
import com.zs.pig.shop.portl.util.MemberUtils;


public class Test {

	public static void main(String[] args) {
		Product goods=new Product();
		goods.setTitle("apple22");
		goods.setId(2L);
		goods.setImg("imgs22");
		RedisUtils  RedisUtils=new RedisUtils();
	    String[] properties =new String[]{"id","price","title","img"};
	    RedisUtils.hset(Constant.SHOPPING_HISTORY +1 ,goods.getId()+"",JsonUtils.toJsonStr(goods,properties),24*60*60);
	    System.out.println("end.....");
	}
}
