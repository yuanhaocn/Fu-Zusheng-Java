# zhengAdmin

基于bootstrap实现的响应式Material Design风格的通用后台管理系统

# zhengAdmin相关博客

- [基于 vue + zhengAdmin 的一套后台模板](https://segmentfault.com/a/1190000010552103 "基于 vue + zhengAdmin 的一套后台模板")

# 在线演示

地址： [http://www.zhangshuzheng.cn/zhengAdmin](http://www.zhangshuzheng.cn/zhengAdmin "zhengAdmin")


![预览效果图](src/images/zheng-upms-theme.png)

![预览效果图](src/images/zheng-cms-theme.png)

![预览效果图](src/images/zheng-pay-theme.png)

![预览效果图](src/images/zheng-ucenter-theme.png)

![预览效果图](src/images/zheng-oss-theme.png)

![预览效果图](src/images/zheng-cms-theme-m1.png)

![预览效果图](src/images/zheng-cms-theme-m2.png)

# License
  MIT

