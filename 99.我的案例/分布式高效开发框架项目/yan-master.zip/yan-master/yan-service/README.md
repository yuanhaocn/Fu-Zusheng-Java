# yan-service
服务模块：核心api接口实现类，用于暴露核心服务