访问路径
http://localhost:8080/pig-blog-portl/front/blog/indexs
http://localhost:8080/pig-blog-portl/front/blog/indexc
http://localhost:8080/pig-blog-portl/front/blog/index
http://localhost:8080/pig-blog-portl/front/blog/indexns

blog前端 主要是调用blog-api的dubbo服务