package io.renren.common.validator.group;

/**
 * 新增数据 Group
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2017-03-16 0:04
 */
public interface AddGroup {
}
