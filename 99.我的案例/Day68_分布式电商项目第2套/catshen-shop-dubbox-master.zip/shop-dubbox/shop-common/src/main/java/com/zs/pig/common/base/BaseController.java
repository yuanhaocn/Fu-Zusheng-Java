package com.zs.pig.common.base;


public class BaseController {
	
	
}
