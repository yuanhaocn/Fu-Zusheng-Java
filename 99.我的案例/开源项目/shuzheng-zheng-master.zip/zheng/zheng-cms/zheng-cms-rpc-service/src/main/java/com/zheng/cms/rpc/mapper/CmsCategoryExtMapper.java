package com.zheng.cms.rpc.mapper;

/**
 * 类目VOMapper
 * Created by shuzheng on 2017/01/07.
 */
public interface CmsCategoryExtMapper {

    int up(Integer articleId);

    int down(Integer articleId);

}