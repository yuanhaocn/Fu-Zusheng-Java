package com.zs.pig.pig_cms;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(1%2);
System.out.println(7%2);

System.out.println(1%3);
System.out.println(7%3);
	}

}
